package filmfinder;

//TODO: parler des hashmap 
import java.util.ArrayList;

public interface Algorithm {
	void initAlgorithm();

	ArrayList<Media> execute();
}
